# app/main.py
from __future__ import annotations

import os, tempfile, json, shutil, traceback, threading, time, collections, hashlib, re
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed as _as_completed
from datetime import datetime as _dt

import requests
from requests.adapters import HTTPAdapter
import yaml
from fastapi import FastAPI, UploadFile, File, Form, Header, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse, Response
from pydantic import BaseModel, Field

from .print_utils import print_pdf_silent, html_to_pdf, set_post_print_delay
from .print_journal import PrintJournal, JobBusy, SubmissionUncertain
from .shopify import fetch_order_by_number, hydrate_order_for_template, ensure_variant_images
from .liquid_template import render_liquid
from starlette.staticfiles import StaticFiles
import base64

# ----------------- config & app -----------------
BASE = Path(__file__).resolve().parent.parent

# Bump on every change that matters to the collector. It is sent as the
# User-Agent and printed at startup, so the server logs show which shop PCs
# run which build.
#   2026.09.23-print-auth: send pc_id + X-PC-Secret on /api/overrides and
#   /api/delivery-label (the collector will start requiring them).
AGENT_VERSION = "2026.10.13-print-receipts"
AGENT_USER_AGENT = f"autoprint-agent/{AGENT_VERSION}"
CONFIG_PATH = BASE / "config.yaml"

def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

app = FastAPI(title="Windows Print Receiver", version="1.0")

def setup_cors(app: FastAPI):
    try:
        cfg = load_config()
        origins = cfg.get("allowed_origins", [])
    except Exception:
        origins = []
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins or ["*"],   # tighten to your domains in prod
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
    )

setup_cors(app)
# Ensure logos directory exists and serve it for browser previews
(BASE / "logos").mkdir(exist_ok=True)
app.mount("/logos", StaticFiles(directory=str(BASE / "logos")), name="logos")

# ----------------- models -----------------
class PDFUrlBody(BaseModel):
    pdf_url: str
    copies: int = 1
    printer: Optional[str] = None
    store: Optional[str] = None

class OrdersBody(BaseModel):
    orders: List[str]
    copies: int = 1
    printer: Optional[str] = None
    store: Optional[str] = None
    job_id: Optional[str] = Field(default=None, min_length=1, max_length=128)
    request_id: Optional[str] = Field(default=None, min_length=1, max_length=128)

# ----------------- helpers -----------------
def check_secret(cfg: dict, x_secret: Optional[str]):
    expect = (cfg or {}).get("shared_secret")
    if expect and x_secret != expect:
        raise ValueError("Unauthorized (bad x-secret)")

def _is_forward_mode(cfg: Dict[str, Any]) -> bool:
    try:
        return str((cfg or {}).get("print_mode") or "local").strip().lower() == "forward"
    except Exception:
        return False

def _forward_base_url(cfg: Dict[str, Any]) -> str:
    return str((cfg or {}).get("forward_to_url") or "").strip().rstrip("/")

def _forward_timeout(cfg: Dict[str, Any]) -> int:
    try:
        return int((cfg or {}).get("forward_timeout_seconds") or 90)
    except Exception:
        return 90

def _forward_secret(cfg: Dict[str, Any]) -> str:
    # Prefer explicit forward_secret; fallback to shared_secret
    return str((cfg or {}).get("forward_secret") or (cfg or {}).get("shared_secret") or "").strip()

def _forward_headers(cfg: Dict[str, Any]) -> Dict[str, str]:
    h: Dict[str, str] = {"X-Print-Forwarded": "1"}
    sec = _forward_secret(cfg)
    if sec:
        h["X-Secret"] = sec
    return h

def _forward_json(cfg: Dict[str, Any], path: str, payload: Dict[str, Any]):
    base = _forward_base_url(cfg)
    if not base:
        raise ValueError("print_mode=forward but forward_to_url is empty")
    url = f"{base}{path}"
    r = requests.post(url, json=payload, headers=_forward_headers(cfg), timeout=_forward_timeout(cfg))
    # Bubble up remote errors
    if r.status_code >= 400:
        raise RuntimeError(f"Forward failed ({r.status_code}): {r.text[:500]}")
    try:
        return r.json()
    except Exception:
        return {"ok": True, "forwarded": True, "raw": r.text}

def _forward_multipart_pdf(cfg: Dict[str, Any], file: UploadFile, copies: int, printer: Optional[str], store: Optional[str]):
    base = _forward_base_url(cfg)
    if not base:
        raise ValueError("print_mode=forward but forward_to_url is empty")
    url = f"{base}/print/pdf-upload"
    content = file.file.read()
    files = {"file": (file.filename or "label.pdf", content, file.content_type or "application/pdf")}
    data = {
        "copies": str(int(copies or 1)),
    }
    if printer is not None:
        data["printer"] = printer
    if store is not None:
        data["store"] = store
    r = requests.post(url, files=files, data=data, headers=_forward_headers(cfg), timeout=_forward_timeout(cfg))
    if r.status_code >= 400:
        raise RuntimeError(f"Forward upload failed ({r.status_code}): {r.text[:500]}")
    try:
        return r.json()
    except Exception:
        return {"ok": True, "forwarded": True, "raw": r.text}

def _json_error(e: Exception, code: int = 400):
    return JSONResponse(
        status_code=code,
        content={
            "ok": False,
            "error": str(e),
            "trace": traceback.format_exc().splitlines()[-8:],
        },
    )

def _select_store(cfg: Dict[str, Any], store_key: Optional[str]) -> Tuple[str, str, str, str, str, str]:
    """
    Returns (shop, token, api_version, currency_suffix, template_name, printer_name)
    Supports both legacy single-store keys and new cfg["stores"][store_key].
    """
    # Defaults from legacy layout
    legacy = {
        "shop_domain": cfg.get("shop_domain", ""),
        "admin_api_token": cfg.get("admin_api_token", ""),
        "admin_api_version": cfg.get("admin_api_version", "2024-07"),
        "currency_suffix": cfg.get("currency_suffix", ""),
        "template": cfg.get("template", "label.liquid"),
        "printer_name": cfg.get("printer_name", ""),
    }

    stores = cfg.get("stores") or {}
    selected = None
    if stores:
        if store_key and store_key in stores:
            selected = stores[store_key]
        else:
            # first store in dict
            first_key = next(iter(stores.keys()))
            selected = stores[first_key]
    data = selected or legacy

    shop = data.get("shop_domain") or legacy["shop_domain"]
    token = data.get("admin_api_token") or legacy["admin_api_token"]
    api_version = data.get("admin_api_version") or legacy["admin_api_version"]
    currency_suffix = data.get("currency_suffix") or legacy["currency_suffix"]
    template_name = data.get("template") or legacy["template"] or "label.liquid"
    printer_name = data.get("printer_name") or legacy["printer_name"]
    printer_name = _normalize_printer_name(printer_name)
    return shop, token, api_version, currency_suffix, template_name, printer_name

def _normalize_printer_name(name: Optional[str]) -> str:
    n = (name or "").strip()
    if not n:
        return ""
    low = n.lower()
    if low in ("default", "system", "auto"):
        return ""
    if n.startswith("<") and n.endswith(">"):
        return ""
    return n

def _parse_order_number_int(order_number: str) -> int:
    try:
        s = str(order_number).lstrip("#").strip()
        digits = "".join(ch for ch in s if ch.isdigit())
        return int(digits) if digits else -1
    except Exception:
        return -1

def _select_store_for_order(cfg: Dict[str, Any], order_number: str, preferred_store: Optional[str]) -> Tuple[str, str, str, str, str, str]:
    # If explicit store is given, honor it
    if preferred_store:
        return _select_store(cfg, preferred_store)

    # Try routing rules in config
    rules = ((cfg.get("routing") or {}).get("by_order_number") or [])
    if rules:
        num = _parse_order_number_int(order_number)
        for rule in rules:
            store_key = (rule or {}).get("store")
            if not store_key:
                continue
            min_v = rule.get("min")
            max_v = rule.get("max")
            if (min_v is None or (isinstance(min_v, int) and num >= min_v)) and (max_v is None or (isinstance(max_v, int) and num <= max_v)):
                return _select_store(cfg, store_key)

    # Fallback simple heuristic if two stores are present
    stores = list((cfg.get("stores") or {}).keys())
    if len(stores) >= 2:
        num = _parse_order_number_int(order_number)
        # Heuristic: >=100000 -> first store, else second
        if num >= 100000:
            return _select_store(cfg, stores[0])
        else:
            return _select_store(cfg, stores[1])

    # Default: legacy / first store
    return _select_store(cfg, None)

# ----------------- relay failover -----------------
# The collector runs in two places during the Cloud Run -> Netcup move, and
# both talk to the SAME Postgres database, so the print queue is one queue no
# matter which host serves it. That makes plain failover safe: try one, and if
# it is unreachable or refuses, use the next.
#
# Configure in config.yaml as a list, most-preferred first:
#
#   relay_urls:
#     - "https://shopify-collector.chattbase.site"
#     - "https://shopify-collector-985002633728.europe-west1.run.app"
#
# The old single `relay_url` still works and is treated as the first entry.
#
# Only ONE url is polled at a time. Never poll both concurrently: /pull claims
# jobs with a SELECT followed by a separate UPDATE, so two pollers on one pc_id
# can lease the same job and print it twice.
_RELAY_LOCK = threading.Lock()
_RELAY_URLS: List[str] = []
_RELAY_IDX = 0


def _relay_candidates(cfg: Dict[str, Any]) -> List[str]:
    urls: List[str] = []
    raw = cfg.get("relay_urls")
    if isinstance(raw, (list, tuple)):
        for u in raw:
            u = str(u or "").strip().rstrip("/")
            if u and u not in urls:
                urls.append(u)
    single = str(cfg.get("relay_url") or "").strip().rstrip("/")
    if single and single not in urls:
        urls.insert(0, single)
    return urls


def _set_relay_urls(cfg: Dict[str, Any]) -> List[str]:
    global _RELAY_URLS, _RELAY_IDX
    with _RELAY_LOCK:
        _RELAY_URLS = _relay_candidates(cfg)
        _RELAY_IDX = 0
        return list(_RELAY_URLS)


def _active_relay() -> str:
    with _RELAY_LOCK:
        return _RELAY_URLS[_RELAY_IDX] if _RELAY_URLS else ""


def _rotate_relay(reason: str) -> str:
    global _RELAY_IDX
    with _RELAY_LOCK:
        if len(_RELAY_URLS) < 2:
            return _RELAY_URLS[0] if _RELAY_URLS else ""
        _RELAY_IDX = (_RELAY_IDX + 1) % len(_RELAY_URLS)
        nxt = _RELAY_URLS[_RELAY_IDX]
    _plog(f"[RELAY] {reason} -- switching to {nxt}")
    return nxt


# ----------------- overrides bridging (collector -> local) -----------------
def _collector_base_url(cfg: Dict[str, Any]) -> str:
    # Reuse the relay as the collector base; both run on the same service.
    # Prefer whichever relay is currently answering, so a failover carries the
    # override/label calls with it instead of stranding them on a dead host.
    return _active_relay() or (cfg.get("relay_url") or "").strip().rstrip("/")

def _collector_auth(cfg: Dict[str, Any]) -> Tuple[Dict[str, str], Dict[str, str]]:
    """(params, headers) that authenticate this PC to the collector.

    The same pc_id / pc_secret the poller already uses for /pull. The secret
    travels only in a header, never in the URL.
    """
    pc_id = str(cfg.get("pc_id") or "").strip()
    pc_secret = str(cfg.get("pc_secret") or "").strip()
    headers = {"User-Agent": AGENT_USER_AGENT}
    if pc_id and pc_secret:
        return {"pc_id": pc_id}, {**headers, "X-PC-Secret": pc_secret}
    return {}, headers

def _build_http_session(pool_size: int = 8) -> requests.Session:
    sess = requests.Session()
    sess.headers["User-Agent"] = AGENT_USER_AGENT
    try:
        adapter = HTTPAdapter(pool_connections=pool_size, pool_maxsize=pool_size, max_retries=0)
        sess.mount("http://", adapter)
        sess.mount("https://", adapter)
    except Exception:
        pass
    return sess

def fetch_overrides_from_collector(
    cfg: Dict[str, Any],
    order_numbers: list[str],
    store: Optional[str],
    session: Optional[requests.Session] = None,
) -> dict[str, dict]:
    base = _collector_base_url(cfg)
    if not base or not order_numbers:
        return {}
    try:
        joined = ",".join(str(n).lstrip("#") for n in order_numbers)
        auth_params, auth_headers = _collector_auth(cfg)
        params = {"orders": joined, **auth_params}
        if store:
            params["store"] = store
        client = session or requests
        r = client.get(f"{base}/api/overrides", params=params, headers=auth_headers, timeout=8)
        r.raise_for_status()
        js = r.json() or {}
        return js.get("overrides") or {}
    except Exception:
        return {}

def _merge_shipping_address(order: dict, override_addr: dict) -> dict:
    if not override_addr:
        return order
    sa = dict(order.get("shipping_address") or {})
    # Prefer override values when present
    for key in ("name","address1","address2","city","zip","province","country","phone"):
        val = override_addr.get(key)
        if val:
            sa[key] = val
    order["shipping_address"] = sa
    return order

def apply_overrides(order: dict, override: dict | None) -> dict:
    if not override:
        return order
    try:
        # email / phone at top-level
        for k in ("email", "phone", "tags"):
            v = override.get(k)
            if v:
                order[k] = v
        # customer display name (template currently does not use, but keep consistent)
        cust = (override.get("customer") or {})
        if cust:
            oc = dict(order.get("customer") or {})
            if cust.get("displayName"):
                oc["first_name"] = (cust.get("displayName") or "").strip()
            if cust.get("email"):
                oc["email"] = cust.get("email")
            if cust.get("phone"):
                oc["phone"] = cust.get("phone")
            order["customer"] = oc
        # shipping address mapping
        order = _merge_shipping_address(order, override.get("shippingAddress") or {})
    except Exception:
        return order
    return order

# ----------------- rate limit helpers -----------------
def _sleep_for_retry(resp, default_delay: float):
    try:
        ra = (resp.headers.get("Retry-After") if resp and getattr(resp, "headers", None) else None)
        delay = float(ra) if ra else float(default_delay)
    except Exception:
        delay = float(default_delay)
    time.sleep(max(0.5, delay))

def _fetch_order_with_retry(shop: str, api_version: str, token: str, num: str, max_retries: int = 5):
    delay = 1.0
    last_exc: Exception | None = None
    for i in range(max(1, max_retries)):
        try:
            return fetch_order_by_number(shop, api_version, token, num)
        except Exception as e:
            resp = getattr(e, "response", None)
            status = None
            try:
                status = resp.status_code if resp is not None else None
            except Exception:
                status = None
            # 429: backoff and retry
            if status == 429 and i < max_retries - 1:
                _sleep_for_retry(resp, delay)
                delay = min(delay * 2.0, 8.0)
                continue
            # 5xx: transient
            if status and 500 <= int(status) < 600 and i < max_retries - 1:
                time.sleep(delay)
                delay = min(delay * 2.0, 8.0)
                continue
            last_exc = e
            break
    if last_exc:
        raise last_exc
    raise RuntimeError("Failed to fetch order after retries")

_shopify_sem_lock = threading.Lock()
_shopify_sem_size = 1
_shopify_sem = threading.BoundedSemaphore(_shopify_sem_size)

def _set_shopify_request_concurrency(value: Any):
    global _shopify_sem_size, _shopify_sem
    try:
        n = max(1, int(value or 1))
    except Exception:
        n = 1
    with _shopify_sem_lock:
        if n != _shopify_sem_size:
            _shopify_sem = threading.BoundedSemaphore(n)
            _shopify_sem_size = n

def _extract_body(html: str, start: str = "<body>", end: str = "</body>") -> str:
    s, e = html.find(start), html.rfind(end)
    return html[s + len(start) : e] if s != -1 and e != -1 and e > s else html

def _extract_style(html: str) -> str:
    s, e = html.find("<style>"), html.rfind("</style>")
    return html[s + 7 : e] if s != -1 and e != -1 and e > s else ""


def _combined_label_html(order_results):
    # Templates style their body as one 100mm label. Apply that layout to EACH
    # page wrapper, rather than flexing every order inside a single label body.
    style = (order_results[0][1] if order_results else "") or "@page { size: 100mm 100mm; margin: 0; }"
    style = re.sub(r"(?<![\w.#-])body\b", ".label-page", style)
    pages = "".join('<section class="label-page">' + result[0] + "</section>" for result in order_results)
    return (
        '<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + style
        + "body{margin:0;padding:0;} .label-page{break-after:page;break-inside:avoid;}"
        + ".label-page:last-child{break-after:auto;}"
        + "</style></head><body>" + pages + "</body></html>"
    )

def _process_single_order(num: str, cfg: dict, overrides_map: dict, store_override: Optional[str]) -> Tuple[str, str, str]:
    """Returns (body_html, style, store_printer). Used for parallel order processing."""
    shop, token, api_version, currency_suffix, template_name, store_printer = _select_store_for_order(cfg, str(num), store_override)
    tpl_path = BASE / "templates" / template_name
    with _shopify_sem:
        order = _fetch_order_with_retry(shop, api_version, token, str(num).lstrip("#"), max_retries=7)
        order = ensure_variant_images(order, shop, api_version, token)
    ov = overrides_map.get(str(num).lstrip("#")) if overrides_map else None
    if ov:
        order = apply_overrides(order, ov)
    order = hydrate_order_for_template(order, currency_suffix=currency_suffix)
    logos_dir = BASE / "logos"
    try:
        logos_available = [p.stem.lower() for p in logos_dir.glob("*.png")]
    except Exception:
        logos_available = []
    order_qr_src = _qr_data_uri(str(order.get("order_number") or ""), size=280)
    wa_qr_src = _qr_data_uri("https://wa.me/212677624078", size=170)
    html = render_liquid(tpl_path, {
        "order": order,
        "logos_base": logos_dir.as_uri(),
        "logos_available": logos_available,
        "order_qr_src": order_qr_src,
        "wa_qr_src": wa_qr_src,
    })
    return _extract_body(html), _extract_style(html), store_printer or ""

# ----------------- batching helper -----------------
def _chunked(seq, size: int):
    try:
        n = int(size)
    except Exception:
        n = 0
    if not seq or n <= 1:
        yield list(seq or [])
        return
    buf = []
    for x in seq:
        buf.append(x)
        if len(buf) >= n:
            yield buf
            buf = []
    if buf:
        yield buf


def _job_receipt(cfg, job_id, payload=None):
    # Namespace by PC; retain receipts across agent restarts and relay failover.
    key = hashlib.sha256(f"{cfg.get('pc_id', '')}\0{job_id}".encode()).hexdigest()
    return PrintJournal(BASE / "state" / "print-jobs.sqlite3").claim(key, payload=payload)


def _submit_pdf(path, cfg, printer, copies=1, receipt=None, part="pdf"):
    if receipt and receipt.is_submitted(part):
        return
    try:
        print_pdf_silent(
            path, printer=printer, sumatra_path=cfg.get("sumatra_path"), copies=copies,
            before_submit=(lambda: receipt.before_submit(part)) if receipt else None,
        )
    except OSError:
        if receipt:
            receipt.not_started(part)
        raise
    if receipt:
        receipt.submitted(part)

# ----------------- routes -----------------
@app.get("/health")
def health():
    return {"ok": True}

@app.get("/status")
def print_queue_status():
    """Live print queue: active jobs, recent history, stats."""
    active, history, stats = _pq.snapshot()
    return {
        "ok": True,
        "stats": stats,
        "active": [
            {"job_id": e.job_id, "kind": e.kind, "desc": e.desc,
             "state": e.state, "elapsed_s": round((_dt.now() - e.t0).total_seconds(), 1)}
            for e in active
        ],
        "recent": [
            {"job_id": e.job_id, "kind": e.kind, "desc": e.desc,
             "state": e.state, "elapsed_s": round((e.t1 - e.t0).total_seconds(), 1) if e.t1 else 0,
             "error": e.error}
            for e in history
        ],
    }

@app.get("/preview/order")
def preview_order(number: str, store: Optional[str] = None, x_secret: Optional[str] = Header(default=None)):
    """
    Render the label HTML for a single Shopify order number for quick preview in a browser.
    """
    try:
        cfg = load_config()
        check_secret(cfg, x_secret)
        shop, token, api_version, currency_suffix, template_name, _ = _select_store_for_order(cfg, str(number), store)
        tpl_path = BASE / "templates" / template_name
        order = fetch_order_by_number(shop, api_version, token, str(number).lstrip("#"))
        # Apply overrides if available
        overrides_map = fetch_overrides_from_collector(cfg, [str(number)], store)
        ov = overrides_map.get(str(number).lstrip("#")) if overrides_map else None
        if ov:
            order = apply_overrides(order, ov)
        order = hydrate_order_for_template(order, currency_suffix=currency_suffix)
        order = ensure_variant_images(order, shop, api_version, token)
        logos_dir = BASE / "logos"
        try:
            logos_available = [p.stem.lower() for p in logos_dir.glob("*.png")]
        except Exception:
            logos_available = []
        # Provide embedded QR data URIs for reliable rendering
        order_qr_src = _qr_data_uri(str(order.get("order_number") or ""), size=280)
        wa_qr_src = _qr_data_uri("https://wa.me/212677624078", size=170)
        html = render_liquid(
            tpl_path,
            {
                "order": order,
                "logos_base": "/logos",
                "logos_available": logos_available,
                "order_qr_src": order_qr_src,
                "wa_qr_src": wa_qr_src,
            },
        )
        return HTMLResponse(content=html)
    except Exception as e:
        return _json_error(e)

@app.get("/qr")
def generate_qr(text: str = Query(...), size: int = Query(170)):
    """
    Generate a QR code PNG locally to avoid external services.
    """
    try:
        import qrcode
        from io import BytesIO
        from PIL import Image
    except Exception as e:
        return _json_error(Exception("QR dependencies missing. Please install 'qrcode' and 'Pillow'."), 500)
    try:
        qr = qrcode.QRCode(border=1, box_size=4)
        qr.add_data(text)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        # Resize to requested square size (pixels)
        size_px = max(16, min(int(size or 170), 1024))
        img = img.resize((size_px, size_px), Image.NEAREST)
        buf = BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return Response(content=buf.getvalue(), media_type="image/png")
    except Exception as e:
        return _json_error(e, 500)

def _qr_data_uri(text: str, size: int = 170) -> str:
    """
    Generate a QR code as a data:image/png;base64 URI for embedding in HTML.
    """
    try:
        import qrcode
        from io import BytesIO
        from PIL import Image
    except Exception:
        # Fallback to external service if local deps missing
        safe = requests.utils.quote(str(text) if text is not None else "")
        s = max(16, min(int(size or 170), 1024))
        return f"https://quickchart.io/barcode?type=qrcode&text={safe}&size={s}"
    size_px = max(16, min(int(size or 170), 1024))
    qr = qrcode.QRCode(border=1, box_size=4)
    qr.add_data(text or "")
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    img = img.resize((size_px, size_px), Image.NEAREST)
    buf = BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/png;base64,{b64}"

@app.post("/print/pdf")
def print_pdf_url(
    b: PDFUrlBody,
    x_secret: Optional[str] = Header(default=None),
    x_print_forwarded: Optional[str] = Header(default=None),
):
    try:
        cfg = load_config()
        check_secret(cfg, x_secret)
        if _is_forward_mode(cfg):
            if x_print_forwarded:
                raise ValueError("Forward loop detected (already forwarded)")
            return _forward_json(cfg, "/print/pdf", b.model_dump())
        # store is irrelevant for direct PDF printing except printer selection
        _, _, _, _, _, store_printer = _select_store(cfg, b.store)
        requested_printer = _normalize_printer_name(b.printer)

        r = requests.get(b.pdf_url, timeout=60)
        r.raise_for_status()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(r.content)
            tmp.flush()
            pdf_path = tmp.name
        try:
            print_pdf_silent(
                pdf_path,
                printer=requested_printer or store_printer or _normalize_printer_name(cfg.get("printer_name")),
                sumatra_path=cfg.get("sumatra_path"),
                copies=b.copies,
            )
            return {"ok": True}
        finally:
            try: os.remove(pdf_path)
            except: pass
    except Exception as e:
        return _json_error(e)

@app.post("/print/pdf-upload")
def print_pdf_upload(
    file: UploadFile = File(...),
    copies: int = Form(1),
    printer: Optional[str] = Form(None),
    store: Optional[str] = Form(None),
    x_secret: Optional[str] = Header(default=None),
    x_print_forwarded: Optional[str] = Header(default=None),
):
    try:
        cfg = load_config()
        check_secret(cfg, x_secret)
        if _is_forward_mode(cfg):
            if x_print_forwarded:
                raise ValueError("Forward loop detected (already forwarded)")
            return _forward_multipart_pdf(cfg, file=file, copies=copies, printer=printer, store=store)
        _, _, _, _, _, store_printer = _select_store(cfg, store)
        requested_printer = _normalize_printer_name(printer)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(file.file.read())
            tmp.flush()
            pdf_path = tmp.name
        try:
            print_pdf_silent(
                pdf_path,
                printer=requested_printer or store_printer or _normalize_printer_name(cfg.get("printer_name")),
                sumatra_path=cfg.get("sumatra_path"),
                copies=int(copies),
            )
            return {"ok": True}
        finally:
            try: os.remove(pdf_path)
            except: pass
    except Exception as e:
        return _json_error(e)

@app.post("/print/orders")
def print_orders(
    b: OrdersBody,
    x_secret: Optional[str] = Header(default=None),
    x_print_forwarded: Optional[str] = Header(default=None),
):
    try:
        cfg = load_config()
        _set_shopify_request_concurrency(cfg.get("shopify_request_concurrency", 1))
        check_secret(cfg, x_secret)
        if _is_forward_mode(cfg):
            if x_print_forwarded:
                raise ValueError("Forward loop detected (already forwarded)")
            return _forward_json(cfg, "/print/orders", b.model_dump())

        receipt = None
        heartbeat_stop = threading.Event()
        try:
            identity = b.job_id or b.request_id
            if identity:
                receipt = _job_receipt(cfg, identity, {"orders": b.orders, "copies": b.copies, "printer": b.printer, "store": b.store})
                if receipt.completed:
                    return {"ok": True, "duplicate": True, "combined": True, "results": [{"order": num, "printed": True, "prepared": True} for num in b.orders]}
                def touch_receipt():
                    while not heartbeat_stop.wait(20):
                        try:
                            receipt.touch()
                        except Exception as exc:
                            _plog(f"[WARN] local receipt heartbeat failed: {exc}")
                threading.Thread(target=touch_receipt, daemon=True).start()
            with _build_http_session() as session:
                _print_job({"orders": b.orders, "copies": b.copies, "printer": b.printer, "store": b.store}, cfg, session=session, receipt=receipt)
            if receipt:
                receipt.finish()
            return {"ok": True, "results": [{"order": num, "printed": True, "prepared": True} for num in b.orders], "combined": True}
        finally:
            heartbeat_stop.set()
            if receipt and not receipt.completed:
                receipt.release()
    except JobBusy as e:
        return _json_error(e, 409)
    except SubmissionUncertain as e:
        return JSONResponse(status_code=409, content={"ok": False, "manual_review": True, "error": str(e)})
    except Exception as e:
        return _json_error(e)

# =====================================================================
#  PRINT QUEUE TRACKER  (thread-safe job tracking + console dashboard)
# =====================================================================
class _JobEntry:
    __slots__ = ("job_id", "kind", "desc", "state", "t0", "t1", "error")
    def __init__(self, job_id: str, kind: str, desc: str):
        self.job_id, self.kind, self.desc = job_id, kind, desc
        self.state = "queued"
        self.t0: _dt = _dt.now()
        self.t1: _dt | None = None
        self.error = ""

class _PrintQueue:
    def __init__(self, history_size: int = 200):
        self._lock = threading.Lock()
        self._active: Dict[str, _JobEntry] = {}
        self._history: collections.deque = collections.deque(maxlen=history_size)
        self.printed = 0
        self.failed = 0
        self.total = 0
        self.started_at = _dt.now()

    def add(self, jid: str, kind: str, desc: str):
        with self._lock:
            self._active[jid] = _JobEntry(jid, kind, desc)
            self.total += 1

    def printing(self, jid: str):
        with self._lock:
            e = self._active.get(jid)
            if e:
                e.state = "printing"

    def done(self, jid: str):
        with self._lock:
            e = self._active.pop(jid, None)
            if e:
                e.state, e.t1 = "done", _dt.now()
                self._history.appendleft(e)
                self.printed += 1

    def fail(self, jid: str, error: str = ""):
        with self._lock:
            e = self._active.pop(jid, None)
            if e:
                e.state, e.t1, e.error = "failed", _dt.now(), error
                self._history.appendleft(e)
                self.failed += 1

    def snapshot(self):
        with self._lock:
            return (
                list(self._active.values()),
                list(self._history)[:15],
                {"printed": self.printed, "failed": self.failed, "total": self.total},
            )

_pq = _PrintQueue()

def _plog(msg: str):
    """Timestamped log for the poller engine."""
    print(f"[{_dt.now().strftime('%H:%M:%S')}] {msg}", flush=True)

def _job_desc(job: dict) -> Tuple[str, str]:
    """Return (kind, short_description) for a relay job."""
    if job.get("type") == "label":
        return "LABEL", f"delivery #{job.get('delivery_order_id', '?')}"
    if job.get("pdf_url"):
        u = job["pdf_url"]
        return "PDF", (u[:45] + "..." if len(u) > 45 else u)
    orders = job.get("orders") or []
    if orders:
        nums = ", ".join(f"#{n}" for n in orders[:4])
        if len(orders) > 4:
            nums += f" +{len(orders) - 4}"
        return "ORDER", nums
    return "JOB", job.get("job_id", "?")[:16]

def _print_status_banner():
    """Print a summary dashboard to the console."""
    active, history, stats = _pq.snapshot()
    up = _dt.now() - _pq.started_at
    h, rem = divmod(int(up.total_seconds()), 3600)
    m, _ = divmod(rem, 60)
    bar = f"printed:{stats['printed']}  failed:{stats['failed']}  total:{stats['total']}  up:{h}h{m:02d}m"
    lines = [f"\n  ==== STATUS  {bar} ===="]
    if active:
        for e in active:
            sec = (_dt.now() - e.t0).total_seconds()
            lines.append(f"    [>>] {e.kind:6s} {e.desc}  ({e.state} {sec:.0f}s)")
    else:
        lines.append("    (idle -- waiting for print jobs)")
    if history:
        lines.append("  recent:")
        for e in history[:7]:
            sec = (e.t1 - e.t0).total_seconds() if e.t1 else 0
            tag = " OK" if e.state == "done" else " !!"
            suffix = f"  err: {e.error}" if e.error else ""
            lines.append(f"    [{tag}] {e.kind:6s} {e.desc}  ({sec:.1f}s){suffix}")
    lines.append("  ====")
    _plog("\n".join(lines))

# ----------------- delivery label printing (from delivery print-agent) -----------------
def _print_delivery_label(job: dict, cfg: dict, session: Optional[requests.Session] = None, receipt=None):
    """Download and print a delivery label. Mirrors print-agent/poller.py logic."""
    if receipt and receipt.is_submitted("label"):
        return
    relay = _collector_base_url(cfg)
    if not relay:
        raise RuntimeError("relay_url not configured – cannot fetch delivery label")

    delivery_order_id = job.get("delivery_order_id", "")
    envoy_code = job.get("envoy_code", "") or ""

    url = f"{relay}/api/delivery-label/{delivery_order_id}"
    params: dict = {"autoprint": "false"}
    if envoy_code:
        params["envoy_code"] = envoy_code

    auth_params, auth_headers = _collector_auth(cfg)
    params.update(auth_params)
    client = session or requests
    r = None
    try:
        req_params = {**params}
        if not envoy_code:
            req_params["format"] = "pdf"
        r = client.get(url, params=req_params, headers=auth_headers, timeout=30)
        r.raise_for_status()
    except Exception:
        r = client.get(url, params=params, headers=auth_headers, timeout=30)
        r.raise_for_status()

    content_type = (r.headers.get("content-type") or "").lower()
    label_printer = _normalize_printer_name(
        cfg.get("delivery_label_printer") or cfg.get("printer_name")
    )
    tmp_dir = tempfile.mkdtemp(prefix="label-")
    try:
        if "application/pdf" in content_type:
            pdf_path = os.path.join(tmp_dir, "label.pdf")
            with open(pdf_path, "wb") as f:
                f.write(r.content)
            _submit_pdf(pdf_path, cfg, label_printer, copies=int(job.get("copies", 1)), receipt=receipt, part="label")
        else:
            html_path = os.path.join(tmp_dir, "label.html")
            pdf_path = os.path.join(tmp_dir, "label.pdf")
            with open(html_path, "wb") as f:
                f.write(r.content)
            html_to_pdf(html_path, pdf_path, chrome_path=cfg.get("chrome_path"), edge_path=cfg.get("edge_path"))
            _submit_pdf(pdf_path, cfg, label_printer, copies=int(job.get("copies", 1)), receipt=receipt, part="label")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

# ----------------- optional: cloud relay poller -----------------
def _print_job(job: dict, cfg: dict, session: Optional[requests.Session] = None, receipt=None):
    # Delivery label jobs (from the delivery app)
    if job.get("type") == "label":
        dlv_id = job.get("delivery_order_id", "")
        print(f"[poller] LABEL {dlv_id}")
        _print_delivery_label(job, cfg, session=session, receipt=receipt)
        return

    # If pdf_url present, print PDF directly
    if job.get("pdf_url"):
        if receipt and receipt.is_submitted("pdf"):
            return
        client = session or requests
        r = client.get(job["pdf_url"], timeout=60)
        r.raise_for_status()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(r.content); tmp.flush(); path = tmp.name
        try:
            _submit_pdf(path, cfg, _normalize_printer_name(job.get("printer") or cfg.get("printer_name")), copies=int(job.get("copies", 1)), receipt=receipt)
        finally:
            try: os.remove(path)
            except: pass
        return

    orders = job.get("orders") or []
    copies = int(job.get("copies", 1))
    if orders:
        chosen_printer = _normalize_printer_name(job.get("printer"))
        overrides_map = fetch_overrides_from_collector(cfg, [str(n) for n in orders], job.get("store"), session=session)
        max_per_batch = int(cfg.get("max_orders_per_batch", 0) or 0)
        order_groups = list(_chunked(orders, max_per_batch)) if (orders and max_per_batch and max_per_batch > 1) else [orders]
        if receipt:
            order_groups = receipt.plan(order_groups)
        fetch_workers = max(1, int(cfg.get("fetch_order_workers", 4)))
        for part, group in enumerate(order_groups):
            if receipt and receipt.is_submitted(part):
                continue
            if not group:
                continue
            with ThreadPoolExecutor(max_workers=fetch_workers) as pool:
                futures = [pool.submit(_process_single_order, str(num), cfg, overrides_map, job.get("store")) for num in group]
                order_results = [f.result() for f in futures]
            if not chosen_printer:
                chosen_printer = next((r[2] for r in order_results if r[2]), "")

            combined = _combined_label_html(order_results)

            with tempfile.NamedTemporaryFile(delete=False, suffix=".html") as fhtml:
                fhtml.write(combined.encode("utf-8")); fhtml.flush()
                out_pdf = fhtml.name.replace(".html", ".pdf")
            try:
                html_to_pdf(fhtml.name, out_pdf, chrome_path=cfg.get("chrome_path"), edge_path=cfg.get("edge_path"))
                _submit_pdf(out_pdf, cfg, chosen_printer or _normalize_printer_name(cfg.get("printer_name")), copies=copies, receipt=receipt, part=part)
            finally:
                for path in (fhtml.name, out_pdf):
                    try: os.remove(path)
                    except OSError: pass


def _handle_relay_job(job, cfg, ack, nack, renew):
    """Keep the lease alive and persist spool receipts independently of ACK."""
    jid = str(job.get("job_id") or "")
    if not jid:
        _plog("[ERR] Relay returned a job without job_id; refusing to print")
        return
    receipt = None
    stop = threading.Event()
    kind, desc = _job_desc(job)
    try:
        receipt = _job_receipt(cfg, jid, {k: v for k, v in job.items() if k not in ("ts", "job_id", "lease_attempt")})
        _pq.add(jid, kind, desc)
        if receipt.completed:
            try:
                ack(jid)
            except Exception as exc:
                _plog(f"[WARN] Already submitted {jid[:8]}, ACK pending: {exc}")
            _pq.done(jid)
            _plog(f"[ACK] Already submitted {jid[:8]}; no reprint")
            return
        _pq.printing(jid)
        lease_ok = threading.Event()
        if not renew(jid):
            raise JobBusy("Relay job is no longer leased")
        lease_ok.set()
        last_renewed = [time.monotonic()]
        receipt.can_submit = lambda: lease_ok.is_set() and time.monotonic() - last_renewed[0] < 60

        def heartbeat():
            while not stop.wait(20):
                try:
                    receipt.touch()
                    if not renew(jid):
                        lease_ok.clear()
                        return
                    last_renewed[0] = time.monotonic()
                except Exception as exc:
                    _plog(f"[WARN] Lease heartbeat {jid[:8]}: {exc}")

        threading.Thread(target=heartbeat, daemon=True, name=f"print-lease-{jid[:8]}").start()
        with _build_http_session() as worker_session:
            _print_job(job, cfg, session=worker_session, receipt=receipt)
        receipt.finish()
        # A failed ACK must never undo the persisted receipt or NACK this job.
        try:
            ack(jid)
        except Exception as exc:
            _plog(f"[WARN] Submitted {jid[:8]}, ACK pending: {exc}")
        _pq.done(jid)
        _plog(f"[OK] {kind:6s} {desc}")
    except JobBusy as exc:
        # Another local process owns it, or its relay lease was lost. Do not
        # mutate that process's lease by NACKing its active job.
        _plog(f"[WAIT] {jid[:8]}: {exc}")
        if receipt:
            _pq.fail(jid, str(exc))
    except Exception as exc:
        err = str(exc)[:250]
        _pq.fail(jid, err)
        _plog(f"[ERR] {kind:6s} {desc}: {err}")
        if not (receipt and receipt.completed):
            status = getattr(getattr(exc, "response", None), "status_code", None)
            try:
                nack(jid, retry=not isinstance(exc, SubmissionUncertain) and status != 404)
            except Exception as nack_exc:
                _plog(f"[WARN] NACK {jid[:8]} failed: {nack_exc}")
    finally:
        stop.set()
        if receipt and not receipt.completed:
            receipt.release()


_poller_started = False
_poller_instance_file = None


def _claim_poller_instance():
    """One relay consumer per installation, including duplicate Windows starts."""
    global _poller_instance_file
    path = BASE / "state" / "poller.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = open(path, "a+b")
    try:
        if os.name == "nt":
            import msvcrt
            if path.stat().st_size == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        return False
    _poller_instance_file = handle
    return True

def start_poller():
    global _poller_started
    if _poller_started:
        return
    try:
        cfg = load_config()
        set_post_print_delay(cfg.get("post_print_delay_seconds", 0))
        _set_shopify_request_concurrency(cfg.get("shopify_request_concurrency", 1))
    except Exception:
        _plog("[poller] cannot load config; disabled")
        return

    relays = _set_relay_urls(cfg)
    relay = relays[0] if relays else ""
    pc_id = cfg.get("pc_id")
    pc_secret = cfg.get("pc_secret")
    if not (relay and pc_id and pc_secret):
        _plog("[poller] relay disabled (set relay_url, pc_id, pc_secret in config.yaml)")
        return

    if not _claim_poller_instance():
        _plog("[poller] another agent is already running in this installation; poller disabled")
        return
    _poller_started = True

    long_poll_sec = int(cfg.get("long_poll_seconds", 20))
    max_workers   = max(1, int(cfg.get("max_workers", 4)))
    # Every leased job starts immediately and gets a heartbeat. Jobs waiting
    # behind a busy executor would otherwise expire before work begins.
    max_items     = min(max_workers, max(1, int(cfg.get("max_items", 10))))
    status_sec    = int(cfg.get("status_interval_seconds", 30))

    sess = _build_http_session(max(4, max_workers * 2))

    # ── relay helpers (connection-pooled) ──
    def _pull() -> list:
        r = sess.get(
            f"{_active_relay()}/pull",
            params={"pc_id": pc_id, "max_items": max_items, "wait": long_poll_sec},
            headers={"X-PC-Secret": pc_secret},
            timeout=long_poll_sec + 15,
        )
        r.raise_for_status()
        return r.json().get("jobs", [])

    def _ack(jid: str, lease_attempt=None):
        r = sess.post(f"{_active_relay()}/ack",
                      json={"pc_id": pc_id, "secret": pc_secret, "job_id": jid, "lease_attempt": lease_attempt}, timeout=10)
        r.raise_for_status()

    def _nack(jid: str, retry=True, lease_attempt=None):
        r = sess.post(f"{_active_relay()}/nack",
                      json={"pc_id": pc_id, "secret": pc_secret, "job_id": jid, "retry": retry, "lease_attempt": lease_attempt}, timeout=10)
        r.raise_for_status()

    def _renew(jid: str, lease_attempt=None):
        # A separate session avoids sharing mutable requests session state with
        # the main pull and print workers. Renewals are small and infrequent.
        r = requests.post(f"{_active_relay()}/renew",
                          headers={"User-Agent": AGENT_USER_AGENT},
                          json={"pc_id": pc_id, "secret": pc_secret, "job_id": jid, "lease_attempt": lease_attempt}, timeout=10)
        r.raise_for_status()
        return bool(r.json().get("renewed"))

    def _handle(job):
        try:
            cfg_now = load_config()
        except Exception:
            cfg_now = cfg
        attempt = job.get("lease_attempt")
        _handle_relay_job(job, cfg_now,
                          lambda jid: _ack(jid, lease_attempt=attempt),
                          lambda jid, retry=True: _nack(jid, retry=retry, lease_attempt=attempt),
                          lambda jid: _renew(jid, lease_attempt=attempt))

    # ── main poller loop ──
    def _poller_loop():
        _plog("=" * 58)
        _plog("  AUTOPRINT ENGINE v2  (parallel + long-poll + reliable)")
        _plog(f"  Version:     {AGENT_VERSION}")
        _plog("=" * 58)
        _plog(f"  Relay:       {_active_relay()}")
        for extra in relays[1:]:
            _plog(f"  Fallback:    {extra}")
        _plog(f"  PC:          {pc_id}")
        _plog(f"  Workers:     {max_workers} parallel")
        _plog(f"  Long-poll:   {long_poll_sec}s  |  Max batch: {max_items}")
        _plog(f"  Status:      every {status_sec}s  |  HTTP: /status")
        _plog("=" * 58)
        _plog("Waiting for print jobs...\n")

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            while True:
                try:
                    jobs = _pull()
                    if not jobs:
                        continue
                    _plog(f"[PULL] {len(jobs)} job(s) received")
                    futs = {pool.submit(_handle, j): j for j in jobs}
                    for fut in _as_completed(futs):
                        try:
                            fut.result()
                        except Exception as e:
                            j = futs[fut]
                            jid = j.get("job_id", "")
                            _plog(f"  [ERR] worker crash {jid[:8]}: {e}")
                            _nack(jid, lease_attempt=j.get("lease_attempt"))
                            _pq.fail(jid, str(e)[:80])

                except requests.exceptions.ConnectionError:
                    _rotate_relay("connection lost")
                    _plog("[NET] connection lost -- retry in 5s")
                    time.sleep(5)
                except requests.exceptions.Timeout:
                    # A long-poll that returns nothing is normal, not a fault.
                    pass
                except requests.exceptions.HTTPError as e:
                    st = getattr(getattr(e, "response", None), "status_code", 0)
                    if st == 401:
                        # Wrong credentials rotate nothing: the other host uses
                        # the same pc_secret, so switching cannot help.
                        _plog("[AUTH] 401 Unauthorized -- check pc_id / pc_secret. Retry in 30s")
                        time.sleep(30)
                    else:
                        # 503 is what a deployment answers while another one
                        # owns the queue (WORKER_LOOPS=0); 404/5xx means it is
                        # not serving. Either way, try the next relay.
                        if st in (403, 404, 500, 502, 503, 504):
                            _rotate_relay(f"HTTP {st}")
                        _plog(f"[HTTP] {e} -- retry in 5s")
                        time.sleep(5)
                except Exception as e:
                    _plog(f"[ERR] {e}")
                    time.sleep(2)

    # ── periodic status dashboard ──
    def _status_loop():
        while True:
            time.sleep(status_sec)
            _print_status_banner()

    threading.Thread(target=_poller_loop, daemon=True, name="autoprint-poller").start()
    threading.Thread(target=_status_loop, daemon=True, name="autoprint-status").start()

# Start only with the HTTP application, never as a side effect of imports.
@app.on_event("startup")
def startup():
    start_poller()

# ----------------- runner -----------------
if __name__ == "__main__":
    import uvicorn
    try:
        cfg = load_config()
        host = cfg.get("host", "127.0.0.1")
        port = int(cfg.get("port", 8787))
    except Exception:
        host, port = "127.0.0.1", 8787
    uvicorn.run(app, host=host, port=port, log_level="info")
